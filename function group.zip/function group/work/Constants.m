F12CONST=Simulink.Parameter;
F12CONST.Value=2;
F12CONST.DataType='single';

F11CONST=Simulink.Parameter;
F11CONST.Value=2;
F11CONST.DataType='single';

MFMdl1CONST=Simulink.Parameter;
MFMdl1CONST.Value=2;
MFMdl1CONST.Description = 'MFMdl1 constant';
MFMdl1CONST.DataType='single';

MFMdl2CONST=Simulink.Parameter;
MFMdl2CONST.Value=2;
MFMdl2CONST.Description = 'MFMdl2 constant';
MFMdl2CONST.DataType='single';

F21CONST=Simulink.Parameter;
F21CONST.Value=2;
F21CONST.Description = 'MFMdl2 constant';
F21CONST.DataType='single';

L222CONST=Simulink.Parameter;
L222CONST.Value=2;
L222CONST.Description = 'L221 constant';
L222CONST.DataType='single';

L221CONST=Simulink.Parameter;
L221CONST.Value=2;
L221CONST.Description = 'L221 constant';
L221CONST.DataType='single';



